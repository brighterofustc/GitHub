/**************************************************************************************************/
/* Copyright (C) XiaoYong, SSE@USTC, 2014-2015                                                    */
/*                                                                                                */
/*  FILE NAME             :  testcase.c                                                           */
/*  PRINCIPAL AUTHOR      :  Fuqiang Zhang                                                             */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  teststub                                                             */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/28                                                           */
/*  DESCRIPTION           :  This is a testcase                                                   */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Fuqiang Zhang, 2014/09/28
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include"menu.h"
#define debug printf

int results[18] = {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
char * info[18] =
{
    "test report",
    "TC1 creat a menu",
    "TC2.0 add a command with the right use-case",
    "TC2.1 add a command with inappropriate input:without cmd",
    "TC2.2 add a command with inappropriate input:without desc",
    "TC2.3 add a command with inappropriate input:without cmd and desc",
    "TC3.0 search help command:the first command(node)",
    "TC3.1 search ping command:the last command(node)",
    "TC3.2 search the last command",
    "TC3.3 search by empty head",
    "TC3.4 search by empty head and command ",
    "TC4.0 delete a command",
    "TC4.1 delete a empty command",
    "TC5.0 modify a command,erase the desc",
    "TC5.1 modify a command,alter the desc",
    "TC6.0 show all commands",
    "TC7.0 menu starts",
    "TC8.0 quit the program",

};

/* init cmd & desc */
static tDataNode data[] =
{
    {NULL, "help", "this is help cmd!", Help},
    {NULL, "quit","quit this program!", Quit},
    {NULL, "qc","this is qc cmd!", NULL},
    {NULL, "mdir","this is mdir cmd!", NULL},
    {NULL, "site","this is site cmd!", NULL},
    {NULL, "disconnect","this is disconnect cmd!", NULL},
    {NULL, "ping","this is ping cmd!", NULL}

};

int main()
{
    int i;
    tLinkTable * head =CreateLinkTable();

    /* test case 1,creat a menu */
    int cm=CreateMenu(head,data);
    {
        if(cm == SUCCESS)
        {
            debug("Test Case 1 Pass\n");
            results[1] = 0;
        }
        else
        {
            printf("Test Case 1 Fail\n");
            results[1] = 1;
        }
    }

    /* test case 2.0,add a command with the right use-case  */
    int ac=AddCmd(head,"kill","this is kill cmd!");
    {
        if(ac == SUCCESS)
        {
            debug("Test Case 2.0 Pass\n");
            results[2] = 0;
        }
        else
        {
            printf("Test Case 2.0 Fail\n");
            results[2] = 1;
        }
    }

    /* test case 2.1,add a command with inappropriate input:without cmd */
    int ac1=AddCmd(head,"","this is a test case");
    {
        if(ac1 == FAILURE)
        {
            debug("Test Case 2.1 Pass\n");
            results[3] = 0;
        }
        else
        {
            printf("Test Case 2.1 Fail\n");
            results[3] = 1;
        }
    }

    /* test case 2.2,add a command with inappropriate input:without desc */
    int ac2=AddCmd(head,"Hello","");
    {
        if(ac2 == FAILURE)
        {
            debug("Test Case 2.2 Pass\n");
            results[4] = 0;
        }
        else
        {
            printf("Test Case 2.2 Fail\n");
            results[4] = 1;
        }
    }

    /* test case 2.3,add a command with inappropriate input:without cmd and desc */
    int ac3=AddCmd(head,"","");
    {
        if(ac3 == FAILURE)
        {
            debug("Test Case 2.3 Pass\n");
            results[5] = 0;
        }
        else
        {
            printf("Test Case 2.3 Fail\n");
            results[5] = 1;
        }
    }

    /* test case 3.0,search help command:the first command(node) */
    int sc=SearchCmd(head, "help");
    {
        if(sc == SUCCESS)
        {
            debug("Test Case 3.0 Pass\n");
            results[6] = 0;
        }
        else
        {
            printf("Test Case 3.1 Fail\n");
            results[6] = 1;
        }
    }

    /* test case 3.1,search ping command:the last command(node) */
    int sc1=SearchCmd(head, "ping");
    {
        if(sc1 == SUCCESS)
        {
            debug("Test Case 3.1 Pass\n");
            results[7] = 0;
        }
        else
        {
            printf("Test Case 3.1 Fail\n");
            results[7] = 1;
        }
    }

    /* test case 3.2,search a empty command */
    int sc2=SearchCmd(head, NULL);
    {
        if(sc2 == FAILURE)
        {
            debug("Test Case 3.2 Pass\n");
            results[8] = 0;
        }
        else
        {
            printf("Test Case 3.2 Fail\n");
            results[8] = 1;
        }
    }

    /* test case 3.3,search by empty head */
    int sc3=SearchCmd(NULL, "mdir");
    {
        if(sc3 == FAILURE)
        {
            debug("Test Case 3.3 Pass\n");
            results[9] = 0;
        }
        else
        {
            printf("Test Case 3.3 Fail\n");
            results[9] = 1;
        }
    }

    /* test case 3.4,search by empty head and command */
    int sc4=SearchCmd(NULL, NULL);
    {
        if(sc4 == FAILURE)
        {
            debug("Test Case 3.4 Pass\n");
            results[10] = 0;
        }
        else
        {
            printf("Test Case 3.4 Fail\n");
            results[10] = 1;
        }
    }

    /* test case 4.0,delete a command */
    int dc=DelCmd(head,"mdir");
    {
        if(dc == SUCCESS)
        {
            debug("Test Case 4.0 Pass\n");
            results[11] = 0;
        }
        else
        {
            printf("Test Case 4.0 Fail\n");
            results[11] = 1;
        }
    }

    /* test case 4.1,delete a empty command */
    int dc1=DelCmd(head,"");
    {
        if(dc1 == FAILURE)
        {
            debug("Test Case 4.1 Pass\n");
            results[12] = 0;
        }
        else
        {
            printf("Test Case 4.1 Fail\n");
            results[12] = 1;
        }
    }

    /* test case 5.0,modify a command,erase the desc*/
    int mc=ModCmd(head,"mdir","");
    {
        if(mc == FAILURE)
        {
            debug("Test Case 5.0 Pass\n");
            results[13] = 0;
        }
        else
        {
            printf("Test Case 5.0 Fail\n");
            results[13] = 1;
        }
    }

    /* test case 5.1,modify a command,alter the desc*/
    int mc1=ModCmd(head,"site","get the site command");
    {
        if(mc1 == SUCCESS)
        {
            debug("Test Case 5.1 Pass\n");
            results[14] = 0;
        }
        else
        {
            printf("Test Case 5.1 Fail\n");
            results[14] = 1;
        }
    }

    /* test case 6.0,show all commands*/
    int h=Help(head);
    {
        if(h== SUCCESS)
        {
            debug("Test Case 6.0 Pass\n");
            results[15] = 0;
        }
        else
        {
            printf("Test Case 6.0 Fail\n");
            results[15] = 1;
        }
    }

    /* test case 7.0,menu starts */
    int ms=MenuStart(head);
    {
        if(ms== SUCCESS)
        {
            debug("Test Case 7.0 Pass\n");
            results[16] = 0;
        }
        else
        {
            printf("Test Case 7.0 Fail\n");
            results[16] = 1;
        }
    }

    /* test case 8.0,quit the program */
    int q=Quit(head);
    {
        if(q== SUCCESS)
        {
            debug("Test Case 8.0 Pass\n");
            results[17] = 0;
        }
        else
        {
            printf("Test Case 8.0 Fail\n");
            results[17] = 1;
        }
    }

    printf("--------------------Test Report-----------------\n");
    for(i=1; i<18; i++)
    {
        if(results[i] == 0)
        {
            printf("Testcase Number %d T - %s\n",i,info[i]);
        }
    }
    return 0;
}
