1 make
2 ./unittest

