/**************************************************************************************************/
/* Copyright (C) , SSE@USTC, 2014-2015                                                            */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Fuqiang Zhang                                                        */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/28                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Fuqiang Zhang, 2014/09/28
 *
 */

#include"linktable.h"
#ifndef _MENU_H_
#define _MENU_H_

#define SUCCESS 0
#define FAILURE (-1)
#define MAX_SIZE 1024

/* define struct */
typedef struct DataNode
{
    tLinkTableNode * pNext;
    char* cmd;
    char* desc;
    int   (*handler)(tLinkTable * head);
}tDataNode;

/*create a menu */
int CreateMenu(tLinkTable* head,tDataNode data[]);
/*search a node*/
int SearchNode(tLinkTableNode *pNode,void* cmd);

/* add a command */
int AddCmd(tLinkTable * p,char * cmd,char * desc);

/* search a command */
int SearchCmd(tLinkTable * head,char * cmd);

/* delete a command */
int DelCmd(tLinkTable * p,char * cmd);

/* Modify a command */
int ModCmd(tLinkTable * p,char * cmd,char * desc);

/* show all commands*/
int Help(tLinkTable * head);

/* quit the program */
int Quit(tLinkTable * head);

/* menu start */
int MenuStart(tLinkTable * tHead);

#endif 
