/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Fuqiang Zhang                                                        */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/30                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Fuqiang Zhang, 2014/09/30
 *
 */

#ifndef _MENU_H_
#define _MENU_H_

#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM     10

/*
 * data struct and its operations
 */

#include "linktable.h"

typedef struct DataNode
{
    tLinkTableNode * pNext;
    char*   cmd;
    char*   desc;
    int     (*handler)();
} tDataNode;


/*
 * add a cmd in the linklist and return the datanode pointer 
 */
 
int AddCmd(tLinkTable * head, tDataNode * cmd);


/*
 * find a cmd in the linklist and return the datanode pointer 
 */
 
tDataNode* FindCmd(tLinkTable * head, char * cmd);


/* 
 * show all cmd in listlist 
 */
 
int ShowAllCmd(tLinkTable * head);

#endif /* _MENU_H_ */
