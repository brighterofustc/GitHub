/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Fuqiang Zhang                                                        */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/30                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Fuqiang Zhang, 2014/09/30
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "linktable.h"

#define DEBUG printf

int Help();
int Quit();

tDataNode cmd[3] = 
{
     {NULL,"help","Menu List",Help},
     {NULL,"version","Menu Program V1.0",NULL},
     {NULL,"quit","Quit from Menu Program V1.0",Quit} 
};

tLinkTable *head=NULL;

int main()
{ 
    head =  CreateLinkTable();
    tDataNode* tdnp = NULL;
 
    DEBUG("Add a command to the LinkTable\n");
    if(AddCmd(head, &cmd[0]) == SUCCESS)
    {
        printf("Add Success\n"); 
    }

    AddCmd(head, &cmd[1]);
    AddCmd(head, &cmd[2]);

    DEBUG("Find a Command which is not exist in the LinkTable.\n");
    if((tdnp = FindCmd(head,"thelp")) == NULL)
    {
        printf("Not Exist Test is pass.\n");
    }else 
    {
        printf("%s - %s\n",tdnp->cmd,tdnp->desc); 
        printf("FindCmd has problems with \"find a not exist command\"\n");
    } 
    
    DEBUG("Find \"help\" Command which is exist in the LinkTable.\n");
    if((tdnp = FindCmd(head,"help")) != NULL)
    {
        printf("%s - %s\n",tdnp->cmd,tdnp->desc);
        
        tdnp->handler();
        
        printf("Exist Test is pass.\n"); 
    }else
    {
        printf("FindCmd has problems with\"find a exist command\"\n");
    }
   
    DEBUG("Show all command in the LinkTable\n");
    if(ShowAllCmd(head) == 3)
    {
       printf("this test has pass.\n");
    }else
    {
       printf("There have some problems in the ShowAllCmd function.\n");
    }

    DEBUG("Find \"quit\" Command which is exist in the LinkTable.\n");
    if((tdnp = FindCmd(head,"quit")) != NULL)
    {
        printf("%s - %s\n",tdnp->cmd,tdnp->desc);
        
        tdnp->handler();
        
        printf("Exist Test is pass.\n"); 
    }else
    {
        printf("FindCmd has problems with\"find a exist command\"\n");
    } 
    
    return 0;
}


int Help()
{
    ShowAllCmd(head);
    return 0; 
}

int Quit()
{
    exit(0);
    return 0;
}

